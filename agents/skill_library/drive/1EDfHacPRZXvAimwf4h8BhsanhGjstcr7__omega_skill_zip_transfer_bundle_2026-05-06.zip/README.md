# Omega Skill Zip Transfer Bundle — 2026-05-06

This bundle contains the uploaded skill/source zip files exactly as received, plus:
- `manifest.json`: filename, size, SHA-256
- `install_to_omega_zips.sh`: helper script for Termux

## Termux target

Copy the contained `.zip` files into:

`~/omega-root/00_INBOX/zips`

Then run:

```bash
python skill_zip_ingest.py
python skill_registry.py
```

Do not execute code inside the zip files directly. The intended flow is:

zip packages → quarantine → manifest scan → skill registry → reviewed adapters → router enablement
