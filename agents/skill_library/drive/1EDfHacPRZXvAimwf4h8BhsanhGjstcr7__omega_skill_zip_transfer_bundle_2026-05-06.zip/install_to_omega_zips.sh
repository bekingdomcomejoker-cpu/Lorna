#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$HOME/omega-root"
DEST="$ROOT/00_INBOX/zips"
SRC_DIR="${1:-$HOME/storage/downloads/omega_skill_zip_transfer_bundle}"

mkdir -p "$DEST"

if [ ! -d "$SRC_DIR/zips" ]; then
  echo "[omega] Expected folder not found: $SRC_DIR/zips"
  echo "[omega] Usage: bash install_to_omega_zips.sh /path/to/unzipped/bundle"
  exit 1
fi

cp -v "$SRC_DIR"/zips/*.zip "$DEST"/

echo "[omega] Copied zips into: $DEST"
echo "[omega] Now run:"
echo "  cd ~/omega-federation-angel-engine"
echo "  python skill_zip_ingest.py"
echo "  python skill_registry.py"
